
import { GoogleGenAI, Type } from "@google/genai";

export const fillTableWithAI = async (title: string, currentHeaders: string[], rowCount: number) => {
  try {
    // 在呼叫時初始化，確保 process.env.API_KEY 已載入
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Generate realistic and professional data for a table titled "${title}". 
      The headers are: ${currentHeaders.join(', ')}. 
      Please provide exactly ${rowCount} rows of data in a nested array format.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            rows: {
              type: Type.ARRAY,
              items: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            }
          },
          required: ["rows"]
        }
      }
    });

    const result = JSON.parse(response.text || '{"rows": []}');
    return result.rows as string[][];
  } catch (error) {
    console.error("Gemini AI Table Fill Error:", error);
    return null;
  }
};
